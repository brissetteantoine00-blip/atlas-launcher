LABYRINTHE RP - DAY / NIGHT CONTRAST EDIT
Based on Spooklementary v2.0.4

DAY
- Much stronger sunlight and skylight
- Brighter, more colorful atmosphere
- More open/clear feeling sky with reduced cloud density
- Stronger daytime godrays

NIGHT
- Very low natural moon/sky illumination
- Cooler blue night tint
- Darker atmospheric contribution for deep shadows
- Artificial lights stay strong and readable
- Stronger colored-light fog and light shafts around lamps

LIGHTS / MATERIALS
- Block light intensity increased
- Emissive texture strength increased to 160%
- Bloom increased for visible glow
- Colored lighting saturation increased
- Puddles/reflections enhanced for rainy/night RP scenes

NOTE: All original Spooklementary menus/options remain available, so values can still be tuned in-game.
