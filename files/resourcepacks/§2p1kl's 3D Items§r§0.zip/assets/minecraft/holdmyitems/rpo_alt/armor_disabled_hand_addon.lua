local hand = context.bl and 1 or -1

if (
        I:isOf(context.item, Items:get("minecraft:creeper_banner_pattern")) or
                I:isOf(context.item, Items:get("minecraft:guster_banner_pattern")) or
                I:isOf(context.item, Items:get("minecraft:mojang_banner_pattern")) or
                I:isOf(context.item, Items:get("minecraft:flow_banner_pattern")) or
                I:isOf(context.item, Items:get("minecraft:field_masoned_banner_pattern")) or
                I:isOf(context.item, Items:get("minecraft:bordure_indented_banner_pattern")) or
                I:isOf(context.item, Items:get("minecraft:flower_banner_pattern")) or
                I:isOf(context.item, Items:get("minecraft:globe_banner_pattern")) or
                I:isOf(context.item, Items:get("minecraft:piglin_banner_pattern")) or
                I:isOf(context.item, Items:get("minecraft:skull_banner_pattern")) or
                I:isOf(context.item, Items:get("minecraft:name_tag"))
) then
    M:moveX(context.matrices, 0 * hand)
    M:moveY(context.matrices, 0.35)
    M:moveZ(context.matrices, 0)
    M:moveX(context.matrices, 0 * hand)
    M:rotateX(context.matrices, 0)
    M:rotateY(context.matrices, 0 * hand)
end